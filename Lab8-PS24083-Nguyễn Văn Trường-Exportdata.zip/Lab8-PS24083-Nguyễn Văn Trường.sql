use quanlybanhang;
alter table san_pham add unique(tenSanPham);
alter table khach_hang add unique(Email);